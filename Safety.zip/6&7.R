input <- mtcars[,c('wt','mpg')]
print(head(input))
# Get the input values.
input <- mtcars[,c('wt','mpg')]

plot(x = input$wt,y = input$mpg,
     xlab = "Weight",
     ylab = "Milage",
     xlim = c(2.5,5),
     ylim = c(15,30),		 
     main = "Weight vs Milage")
library(ggplot2)
data("mtcars")
df <- mtcars
df$cyl <- as.factor(df$cyl)
ggplot(df, aes(x = wt, y = disp)) +
  geom_point(aes(color = cyl, size = qsec), alpha = 0.5) +
  scale_color_manual(values = c("#AA4371", "#E7B800", "#FC4E07")) +
  scale_size(range = c(1, 13)) + # Adjust the range of points size
  theme_set(theme_bw() +theme(legend.position = "bottom"))
ggplot(data = input, aes(x = mpg)) +
  geom_density(fill = 'cyan')
