#label= obama_approval_ratings$Issue
#hist(obama_approval_ratings$Approve,col=c ("violet", "Chocolate2"), xlab= "Issue", las =1, main= "color histogram"))

     
y <- runif(1000)                                             # Create more variables
z <- rpois(1000, 3)   
data <- data.frame(values = c(x, y, z),                      # Combine variables in data frame
                   group = c(rep("x", 1000),
                             rep("y", 1000),
                             rep("z", 1000)))
head(data)  
boxplot(values ~ group, data)  

library(plotly)

fig <- plot_ly(
  type = "indicator",
  mode = "number+gauge+delta",
  gauge = list(shape = "bullet"),
  delta = list(reference = 300),
  value = 220,
  domain = list(x = c(0, 1), y = c(0, 1)),
  title= list(text = "Profit"),
  height = 150)

fig