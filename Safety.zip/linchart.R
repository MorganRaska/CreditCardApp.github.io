plot(hotdog_contest_winners$`Dogs eaten`,type = "o",xlab = "Winners", ylab = "Hotdog Count", main = "Hotdogs to Win")

library(ggplot2)

d=data.frame(y=c(1,2,3,4,5,6,7,8,9,10), x=c(1,2,3,4,5,6,7,8,9,10))

ggplot()+ geom_step(data=d, mapping=aes(x=x, y=y)) +
  geom_step(data=d, mapping=aes(x=x, y=y), direction="vh", linetype=3) +
  geom_point(data=d, mapping=aes(x=x, y=y), color="red") +labs(title= 'Avocados Eaten weekly',x= 'Individuals',y= 'Number of avocados')
