# The mtcars dataset:
data <- as.matrix(mtcars)

# Default Heatmap
heatmap(data)

philly_crimes_sf <-  st_read("data/PhillyCrimerate/", quiet = TRUE)
plot(philly_crimes_sf)


library(plotly)
fig <- plot_ly(z = ~volcano, type = "contour")

fig

