library(plotly)

fig <- plot_ly(
  type="treemap",
  labels=c("Eve", "Cain", "Seth", "Enos", "Noam", "Abel", "Awan", "Enoch", "Azura"),
  parents=c("", "Eve", "Eve", "Seth", "Seth", "Eve", "Eve", "Awan", "Eve")
)
fig
library(ggplot2)
plot = ggplot(obama_approval_ratings, aes(x=obama_approval_ratings$Disapprove, y=obama_approval_ratings$Approve, fill=obama_approval_ratings$Issue))
plot + geom_area()

